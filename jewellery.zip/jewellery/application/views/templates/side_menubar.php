<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">

            <li id="dashboardMainMenu">
                <a href="<?php echo base_url('dashboard') ?>">
                    <i class="fa fa-pie-chart"></i> <span>Dashboard</span>
                </a>
            </li>

            <?php if(in_array('createCategory', $user_permission) || in_array('updateCategory', $user_permission) || in_array('viewCategory', $user_permission) || in_array('deleteCategory', $user_permission)): ?>
            <li id="categoryNav">
                <a href="<?php echo base_url('Controller_Category/') ?>">
                    <i class="fa fa-cubes"></i> <span>Category</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if(in_array('createProduct', $user_permission) || in_array('updateProduct', $user_permission) || in_array('viewProduct', $user_permission) || in_array('deleteProduct', $user_permission)): ?>
            <li id="categoryNav">
            <li id="manageProductNav"><a href="<?php echo base_url('Controller_Products') ?>"><i
                        class="fa fa-cart-arrow-down"></i> Products</a></li>
            </li>


            <?php endif; ?>
            <!-- user permission info -->
            <li><a href="<?php echo base_url('auth/logout') ?>"><i class="fa fa-power-off"></i> <span>Logout</span></a>
            </li>

        </ul>
    </section>
    <!-- /.sidebar -->
</aside>