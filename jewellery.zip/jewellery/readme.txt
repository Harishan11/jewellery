PHP Version 7.4

Codeigniter 3.1.6

Login credentials:
Email	: admin@gmail.com
Password: Password@123